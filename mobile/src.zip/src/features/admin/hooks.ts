﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
export const hooks = {}; // TODO: implementar hooks (useQuery/useMutation)
