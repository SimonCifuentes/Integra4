﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { http } from "@/src/services/http";
import { R } from "@/src/config/routes";
export const api = {}; // TODO: implementar endpoints de este módulo
