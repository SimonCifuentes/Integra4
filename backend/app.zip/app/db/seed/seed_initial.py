def run():
    # TODO: crear superadmin y catálogos (deportes, servicios, etc.)
    print("Seed inicial pendiente...")
