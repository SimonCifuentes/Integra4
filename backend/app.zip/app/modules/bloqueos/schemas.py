from pydantic import BaseModel

class Placeholder(BaseModel):
    pass
