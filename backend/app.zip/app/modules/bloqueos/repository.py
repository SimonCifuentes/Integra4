class Repository:
    pass
