from .interface import Storage
class S3Storage(Storage):
    pass
