from .interface import Storage
class LocalStorage(Storage):
    pass
