def send_mail(to: str, subject: str, body: str):
    pass
